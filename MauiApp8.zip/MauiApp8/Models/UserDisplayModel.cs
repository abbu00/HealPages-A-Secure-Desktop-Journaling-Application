namespace MauiApp8.Models;

public class UserDisplayModel
{
    public int Id { get; set; }
    public string Name { get; set; } = string.Empty;
    public string Email { get; set; } = string.Empty;
    public string CreatedAt { get; set; } = string.Empty; // Formatted for display
}