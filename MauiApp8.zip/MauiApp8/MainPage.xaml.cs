﻿namespace MauiApp8;

public partial class MainPage : ContentPage
{
    public MainPage()
    {
        InitializeComponent();
    }
}