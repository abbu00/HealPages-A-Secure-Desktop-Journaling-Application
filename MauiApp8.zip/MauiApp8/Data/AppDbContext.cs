using Microsoft.EntityFrameworkCore;
using MauiApp8.Entities;

namespace MauiApp8.Data;

public class AppDbContext : DbContext
{
    public DbSet<User> Users { get; set; }

    private readonly string _dbPath;

    public AppDbContext()
    {
        var folder = Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData);
        _dbPath = Path.Combine(folder, "app.db");
    }

    protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
    {
        optionsBuilder.UseSqlite($"Data Source={_dbPath}");
    }
}