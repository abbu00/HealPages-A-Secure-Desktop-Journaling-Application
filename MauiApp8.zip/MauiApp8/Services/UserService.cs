using MauiApp8.Common;
using MauiApp8.Data;
using MauiApp8.Entities;
using MauiApp8.Models;
using Microsoft.EntityFrameworkCore;

namespace MauiApp8.Services;

public interface IUserService
{
    Task<ServiceResult<UserDisplayModel>> AddUserAsync(UserViewModel model);
    Task<ServiceResult<List<UserDisplayModel>>> GetAllUsersAsync();
    Task<ServiceResult<bool>> DeleteUserAsync(int id);
}

public class UserService : IUserService
{
    private readonly AppDbContext _context;

    public UserService(AppDbContext context)
    {
        _context = context;
    }

    public async Task<ServiceResult<UserDisplayModel>> AddUserAsync(UserViewModel model)
    {
        try
        {
            var user = new User { Name = model.Name, Email = model.Email };
            _context.Users.Add(user);
            await _context.SaveChangesAsync();

            var display = MapToDisplay(user);
            return ServiceResult<UserDisplayModel>.Ok(display);
        }
        catch (Exception ex)
        {
            return ServiceResult<UserDisplayModel>.Fail(ex.Message);
        }
    }

    public async Task<ServiceResult<List<UserDisplayModel>>> GetAllUsersAsync()
    {
        try
        {
            var users = await _context.Users.ToListAsync();
            var displays = users.Select(MapToDisplay).ToList();
            return ServiceResult<List<UserDisplayModel>>.Ok(displays);
        }
        catch (Exception ex)
        {
            return ServiceResult<List<UserDisplayModel>>.Fail(ex.Message);
        }
    }

    public async Task<ServiceResult<bool>> DeleteUserAsync(int id)
    {
        try
        {
            var user = await _context.Users.FindAsync(id);
            if (user == null) return ServiceResult<bool>.Fail("User not found");

            _context.Users.Remove(user);
            await _context.SaveChangesAsync();
            return ServiceResult<bool>.Ok(true);
        }
        catch (Exception ex)
        {
            return ServiceResult<bool>.Fail(ex.Message);
        }
    }

    private UserDisplayModel MapToDisplay(User user) => new()
    {
        Id = user.Id,
        Name = user.Name,
        Email = user.Email,
        CreatedAt = user.CreatedAt.ToString("yyyy-MM-dd HH:mm")
    };
}
