using Microsoft.Maui.Controls;

namespace HealPages.Views
{
    public partial class MainPage : ContentPage
    {
        public MainPage()
        {
            InitializeComponent();
        }
    }
}
