﻿namespace HealPages.Models;

public enum Mood
{
    Happy,
    Sad,
    Neutral,
    Angry,
    Calm,
    Excited,
    Celebratory,
    Relaxed
}
